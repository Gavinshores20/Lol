extends  Control

@onready var mine_animation_player: AnimationPlayer = $AnimationPlayer
@onready var mine_label: Label = $"MarginContainer/PanelContainer/MarginContainer/HBoxContainer/mine space/MarginContainer/VBoxContainer/Label"

var iron = 0

func _ready() -> void:
	update_text()


func _on_button_pressed() -> void:
	mine_animation_player.play("mine")
	

var output = 1
func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	iron += output
	update_text() #show current iron amount
	

var output_cost = 2
@onready var output_upgrade_button: Button = $MarginContainer/PanelContainer/MarginContainer/HBoxContainer/upgrades/MarginContainer/VBoxContainer/OutputUpgradeButton2
func _on_output_upgrade_button_2_pressed() -> void:
	if iron >= output_cost: #if I can afford the upgrade
		iron -= output_cost #charge you for it
		output +=1 #reward increase the output
		mine_label.text = "iron: " +str(iron) #shows updated amount you have after buying upgrade
		output_upgrade_button.text = "output \n"+str(output_cost)
		update_text()

func update_text():
	output_upgrade_button.text = "output \nPrice:"+str(output_cost)
	mine_label.text = "iron: " +str(iron)
